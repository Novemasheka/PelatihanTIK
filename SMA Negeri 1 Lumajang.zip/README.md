# PelatihanTIK
Aku diberikan materi tentang membuat website yang sudah aku ketahui :), tapi meskipun begitu aku tetap membutuhkan ilmu yang diberikannya 
